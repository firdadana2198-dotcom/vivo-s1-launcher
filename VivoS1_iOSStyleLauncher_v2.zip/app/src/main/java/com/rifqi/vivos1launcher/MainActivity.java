package com.rifqi.vivos1launcher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, grid, dock;
    TextView clock, date, pages;
    float downX, downY;
    int page=0;
    final int PAGE_SIZE=20;
    ArrayList<ResolveInfo> apps=new ArrayList<>();

    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable round(int color,float r){
        GradientDrawable g=new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(r)); return g;
    }
    TextView text(String s,float z,int c){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(z);
        t.setTextColor(c); t.setGravity(Gravity.CENTER); return t;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE|
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|
            View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        loadApps(); build();
    }

    void loadApps(){
        Intent q=new Intent(Intent.ACTION_MAIN);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> l=getPackageManager().queryIntentActivities(q,0);
        Collections.sort(l,(a,b)->a.loadLabel(getPackageManager()).toString()
            .compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
        apps.addAll(l);
    }

    void build(){
        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(13),dp(30),dp(13),dp(7));
        root.setBackgroundColor(Color.rgb(35,74,120));

        LinearLayout header=new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        clock=text("",17,Color.WHITE); clock.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        date=text("",13,0xFFEAF3FF);
        header.addView(clock,new LinearLayout.LayoutParams(0,dp(45),1));
        header.addView(date,new LinearLayout.LayoutParams(dp(145),dp(45)));
        root.addView(header);

        grid=new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        root.addView(grid,new LinearLayout.LayoutParams(-1,0,1));

        pages=text("",11,0xCCFFFFFF);
        root.addView(pages,new LinearLayout.LayoutParams(-1,dp(22)));

        dock=new LinearLayout(this);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(dp(8),dp(7),dp(8),dp(7));
        dock.setBackground(round(0x66FFFFFF,25));
        root.addView(dock,new LinearLayout.LayoutParams(-1,dp(79)));

        setContentView(root);
        render();
        gesture();
        ticker();
    }

    void render(){
        grid.removeAllViews();
        int start=page*PAGE_SIZE, end=Math.min(apps.size(),start+PAGE_SIZE);
        for(int r=0;r<5;r++){
            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER);
            for(int c=0;c<4;c++){
                int idx=start+r*4+c;
                FrameLayout cell=new FrameLayout(this);
                if(idx<end) app(cell,apps.get(idx));
                row.addView(cell,new LinearLayout.LayoutParams(0,0,1));
            }
            grid.addView(row,new LinearLayout.LayoutParams(-1,0,1));
        }
        pages.setText(pageDots());
        dock();
    }

    String pageDots(){
        int total=Math.max(1,(apps.size()+PAGE_SIZE-1)/PAGE_SIZE);
        StringBuilder s=new StringBuilder();
        for(int i=0;i<total;i++) s.append(i==page?"● ":"○ ");
        return s.toString();
    }

    void app(FrameLayout cell,ResolveInfo info){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        ImageView icon=new ImageView(this);
        icon.setImageDrawable(info.loadIcon(getPackageManager()));
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        TextView name=text(info.loadLabel(getPackageManager()).toString(),10.5f,Color.WHITE);
        name.setMaxLines(1);
        box.addView(icon,new LinearLayout.LayoutParams(dp(57),dp(57)));
        box.addView(name,new LinearLayout.LayoutParams(-1,dp(24)));
        box.setOnClickListener(v->launch(info));
        cell.addView(box,new FrameLayout.LayoutParams(-1,-1));
    }

    void launch(ResolveInfo info){
        Intent i=new Intent();
        i.setClassName(info.activityInfo.packageName,info.activityInfo.name);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    void dock(){
        dock.removeAllViews();
        int n=Math.min(4,apps.size());
        for(int k=0;k<n;k++){
            ResolveInfo info=apps.get(k);
            ImageButton b=new ImageButton(this);
            b.setImageDrawable(info.loadIcon(getPackageManager()));
            b.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            b.setPadding(dp(8),dp(8),dp(8),dp(8));
            b.setBackground(round(0x25FFFFFF,18));
            b.setOnClickListener(v->launch(info));
            dock.addView(b,new LinearLayout.LayoutParams(0,dp(64),1));
        }
    }

    void gesture(){
        root.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){
                downX=e.getX(); downY=e.getY(); return true;
            }
            if(e.getAction()==MotionEvent.ACTION_UP){
                float dx=e.getX()-downX, dy=e.getY()-downY;
                if(Math.abs(dx)>dp(70)&&Math.abs(dx)>Math.abs(dy)){
                    if(dx<0 && (page+1)*PAGE_SIZE<apps.size()) page++;
                    if(dx>0 && page>0) page--;
                    render(); return true;
                }
                if(dy<-dp(90)){
                    showAllApps(); return true;
                }
            }
            return true;
        });
    }

    void showAllApps(){
        final Dialog d=new Dialog(this);
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18),dp(18),dp(18),dp(18));
        box.setBackground(round(0xFFF7F7F7,28));
        TextView title=text("App Library",24,Color.BLACK);
        title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        box.addView(title,new LinearLayout.LayoutParams(-1,dp(55)));
        GridLayout g=new GridLayout(this); g.setColumnCount(4);
        for(ResolveInfo info:apps){
            LinearLayout a=new LinearLayout(this);
            a.setOrientation(LinearLayout.VERTICAL); a.setGravity(Gravity.CENTER);
            ImageView im=new ImageView(this); im.setImageDrawable(info.loadIcon(getPackageManager()));
            TextView nm=text(info.loadLabel(getPackageManager()).toString(),9,Color.DKGRAY);
            nm.setMaxLines(1);
            a.addView(im,new LinearLayout.LayoutParams(dp(52),dp(52)));
            a.addView(nm,new LinearLayout.LayoutParams(dp(72),dp(24)));
            a.setOnClickListener(v->{d.dismiss();launch(info);});
            g.addView(a);
        }
        ScrollView sc=new ScrollView(this); sc.addView(g);
        box.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        d.setContentView(box);
        Window w=d.getWindow();
        if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(-1,-1);}
        d.show();
        if(d.getWindow()!=null)d.getWindow().setLayout(-1,-1);
    }

    void ticker(){
        Handler h=new Handler();
        Runnable r=new Runnable(){public void run(){
            Date d=new Date();
            clock.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(d));
            date.setText(new SimpleDateFormat("EEE, dd MMM",Locale.getDefault()).format(d));
            h.postDelayed(this,1000);
        }};
        h.post(r);
    }
}